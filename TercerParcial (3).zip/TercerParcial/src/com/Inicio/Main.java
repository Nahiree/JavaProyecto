package com.Inicio;
import com.frames.*;

public class Main {
	public static void main (String...args) {
		FrmInicio frm = new FrmInicio();
		frm.setVisible(true);
	}
}
