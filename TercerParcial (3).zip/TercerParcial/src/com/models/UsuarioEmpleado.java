package com.models;

public class UsuarioEmpleado extends Usuario{
	int id_empleado;
	
	public UsuarioEmpleado() {
	}
	
	public int getid_empleado() {
		return id_empleado;
	}
	
	public void setid_empleado(int i) {
		id_empleado = i;
	}
	
	public void verificar_empleado() {
		
	}

}
